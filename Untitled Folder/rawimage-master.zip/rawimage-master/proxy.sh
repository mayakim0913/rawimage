export FTP_PROXY=http://proxy-us.intel.com:911
export HTTP_PROXY=http://proxy-us.intel.com:911 
export HTTPS_PROXY=https://proxy-us.intel.com:911
export NO_PROXY=localhost,.intel.com,127.0.0.0/8,172.16.0.0/20,192.168.0.0/16,10.0.0.0/8
export ftp_proxy=http://proxy-us.intel.com:911
export http_proxy=http://proxy-us.intel.com:911 
export https_proxy=https://proxy-us.intel.com:911
export no_proxy=localhost,.intel.com,127.0.0.0/8,172.16.0.0/20,192.168.0.0/16,10.0.0.0/8

